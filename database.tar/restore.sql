--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE api;
--
-- Name: api; Type: DATABASE; Schema: -; Owner: me
--

CREATE DATABASE api WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C';


ALTER DATABASE api OWNER TO me;

\connect api

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address; Type: TABLE; Schema: public; Owner: me
--

CREATE TABLE public.address (
    addressid integer NOT NULL,
    street character varying(255),
    state character varying(50),
    address character varying(255),
    country character varying(50)
);


ALTER TABLE public.address OWNER TO me;

--
-- Name: address_addressid_seq; Type: SEQUENCE; Schema: public; Owner: me
--

ALTER TABLE public.address ALTER COLUMN addressid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.address_addressid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: document; Type: TABLE; Schema: public; Owner: me
--

CREATE TABLE public.document (
    documentid integer NOT NULL,
    documentnumber character varying(50),
    documenttype character varying(50)
);


ALTER TABLE public.document OWNER TO me;

--
-- Name: document_documentid_seq; Type: SEQUENCE; Schema: public; Owner: me
--

ALTER TABLE public.document ALTER COLUMN documentid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.document_documentid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: farmer; Type: TABLE; Schema: public; Owner: me
--

CREATE TABLE public.farmer (
    farmerid integer NOT NULL,
    name character varying(255),
    document integer,
    address integer
);


ALTER TABLE public.farmer OWNER TO me;

--
-- Name: farmer_farmerid_seq; Type: SEQUENCE; Schema: public; Owner: me
--

ALTER TABLE public.farmer ALTER COLUMN farmerid ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.farmer_farmerid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: me
--

COPY public.address (addressid, street, state, address, country) FROM stdin;
\.
COPY public.address (addressid, street, state, address, country) FROM '$$PATH$$/3241.dat';

--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: me
--

COPY public.document (documentid, documentnumber, documenttype) FROM stdin;
\.
COPY public.document (documentid, documentnumber, documenttype) FROM '$$PATH$$/3239.dat';

--
-- Data for Name: farmer; Type: TABLE DATA; Schema: public; Owner: me
--

COPY public.farmer (farmerid, name, document, address) FROM stdin;
\.
COPY public.farmer (farmerid, name, document, address) FROM '$$PATH$$/3243.dat';

--
-- Name: address_addressid_seq; Type: SEQUENCE SET; Schema: public; Owner: me
--

SELECT pg_catalog.setval('public.address_addressid_seq', 2, true);


--
-- Name: document_documentid_seq; Type: SEQUENCE SET; Schema: public; Owner: me
--

SELECT pg_catalog.setval('public.document_documentid_seq', 3, true);


--
-- Name: farmer_farmerid_seq; Type: SEQUENCE SET; Schema: public; Owner: me
--

SELECT pg_catalog.setval('public.farmer_farmerid_seq', 2, true);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: public; Owner: me
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (addressid);


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: me
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (documentid);


--
-- Name: farmer farmer_pkey; Type: CONSTRAINT; Schema: public; Owner: me
--

ALTER TABLE ONLY public.farmer
    ADD CONSTRAINT farmer_pkey PRIMARY KEY (farmerid);


--
-- Name: farmer fkaddress; Type: FK CONSTRAINT; Schema: public; Owner: me
--

ALTER TABLE ONLY public.farmer
    ADD CONSTRAINT fkaddress FOREIGN KEY (address) REFERENCES public.address(addressid);


--
-- Name: farmer fkdocument; Type: FK CONSTRAINT; Schema: public; Owner: me
--

ALTER TABLE ONLY public.farmer
    ADD CONSTRAINT fkdocument FOREIGN KEY (document) REFERENCES public.document(documentid);


--
-- PostgreSQL database dump complete
--

